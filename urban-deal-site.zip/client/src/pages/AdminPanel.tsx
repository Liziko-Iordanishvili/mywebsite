import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import { Trash2, Edit2, Plus, Upload, X } from "lucide-react";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";

export default function AdminPanel() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [redirecting, setRedirecting] = useState(false);
  const [uploading, setUploading] = useState(false);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      setRedirecting(true);
      window.location.href = getLoginUrl();
    }
  }, [authLoading, isAuthenticated]);

  const [formData, setFormData] = useState({
    name: "",
    brand: "",
    category: "",
    description: "",
    price: "",
    imageUrl: "",
    sizes: [] as string[],
  });

  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [sizeInput, setSizeInput] = useState("");
  const [fileInputRef, setFileInputRef] = useState<HTMLInputElement | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [showImageManager, setShowImageManager] = useState(false);
  const [selectedProductForImages, setSelectedProductForImages] = useState<any>(null);

  // Queries and mutations
  const { data: products, isLoading, refetch } = trpc.products.list.useQuery();
  const createMutation = trpc.products.create.useMutation();
  const updateMutation = trpc.products.update.useMutation();
  const deleteMutation = trpc.products.delete.useMutation();
  const uploadImageMutation = trpc.products.uploadImage.useMutation();
  const addImageMutation = trpc.products.addImage.useMutation();
  const deleteImageMutation = trpc.products.deleteImage.useMutation();
  const getImagesMutation = trpc.products.getImages.useQuery({ productId: editingId || 0 }, { enabled: editingId !== null && editingId !== 0 });

  // Show loading while checking authentication
  if (authLoading || redirecting) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  // Check if user is authenticated and is admin
  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p className="text-gray-400 mb-6">You must be logged in as an admin to access this page.</p>
          <a href={getLoginUrl()}>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
              Log In as Admin
            </Button>
          </a>
        </div>
      </div>
    );
  }

  const processFiles = async (files: FileList) => {
    if (!files || files.length === 0) return;

    setUploading(true);
    const newImages: string[] = [];

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];

        // Validate file size (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
          toast.error(`${file.name} is larger than 5MB`);
          continue;
        }

        // Validate file type
        if (!file.type.startsWith("image/")) {
          toast.error(`${file.name} is not an image`);
          continue;
        }

        const arrayBuffer = await file.arrayBuffer();
        const uint8Array = new Uint8Array(arrayBuffer);

        const result = await uploadImageMutation.mutateAsync({
          file: uint8Array,
          filename: file.name,
          mimeType: file.type,
        });

        if (result.success && result.url) {
          newImages.push(result.url);
        }
      }

      if (newImages.length > 0) {
        setUploadedImages([...uploadedImages, ...newImages]);
        toast.success(`${newImages.length} image(s) uploaded successfully!`);
      }
    } catch (error: any) {
      toast.error(error.message || "Failed to upload images");
    } finally {
      setUploading(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    await processFiles(files!);
    // Reset file input
    e.target.value = "";
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    const files = e.dataTransfer.files;
    await processFiles(files);
  };

  const removeUploadedImage = (index: number) => {
    setUploadedImages(uploadedImages.filter((_, i) => i !== index));
  };

  const openImageManager = async (product: any) => {
    setSelectedProductForImages(product);
    setShowImageManager(true);
    setUploadedImages([]);

    // Fetch existing images for this product
    try {
      const response = await fetch(
        `/api/trpc/products.getImages?input=${encodeURIComponent(JSON.stringify({ productId: product.id }))}`
      );
      const result = await response.json();
      const productImages = result.result?.data || [];
      const imageUrls = productImages.map((img: any) => img.imageUrl).filter((url: string) => url);
      setUploadedImages(imageUrls);
    } catch (error) {
      console.error("Failed to fetch product images:", error);
    }
  };

  const saveProductImages = async () => {
    if (!selectedProductForImages) return;

    try {
      // Get existing images
      const response = await fetch(
        `/api/trpc/products.getImages?input=${encodeURIComponent(JSON.stringify({ productId: selectedProductForImages.id }))}`
      );
      const result = await response.json();
      const existingImages = result.result?.data || [];
      const existingUrls = new Set(existingImages.map((img: any) => img.imageUrl));

      // Add new images that don't already exist
      for (let i = 0; i < uploadedImages.length; i++) {
        const imageUrl = uploadedImages[i];
        if (!existingUrls.has(imageUrl)) {
          await addImageMutation.mutateAsync({
            productId: selectedProductForImages.id,
            imageUrl,
            displayOrder: i,
          });
        }
      }

      toast.success("Product images updated successfully!");
      setShowImageManager(false);
      setSelectedProductForImages(null);
      setUploadedImages([]);
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Failed to save images");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.brand || !formData.category || !formData.price || formData.sizes.length === 0) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      let productId: number | null = editingId;

      if (editingId) {
        await updateMutation.mutateAsync({
          id: editingId,
          ...formData,
          imageUrl: uploadedImages.length > 0 ? uploadedImages[0] : formData.imageUrl,
        });
        toast.success("Product updated successfully!");
      } else {
        const newProduct = await createMutation.mutateAsync({
          ...formData,
          imageUrl: uploadedImages.length > 0 ? uploadedImages[0] : formData.imageUrl,
        });
        productId = newProduct?.id || null;
        toast.success("Product created successfully!");
      }

      // Add uploaded images to productImages table
      if (productId && uploadedImages.length > 0) {
        for (let i = 0; i < uploadedImages.length; i++) {
          await addImageMutation.mutateAsync({
            productId,
            imageUrl: uploadedImages[i],
            displayOrder: i,
          });
        }
      }

      // Reset form
      setFormData({
        name: "",
        brand: "",
        category: "",
        description: "",
        price: "",
        imageUrl: "",
        sizes: [],
      });
      setUploadedImages([]);
      setSizeInput("");
      setEditingId(null);
      setShowForm(false);
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Failed to save product");
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this product?")) {
      try {
        await deleteMutation.mutateAsync({ id });
        toast.success("Product deleted successfully!");
        refetch();
      } catch (error: any) {
        toast.error(error.message || "Failed to delete product");
      }
    }
  };

  const handleEdit = async (product: any) => {
    setFormData({
      name: product.name,
      brand: product.brand,
      category: product.category,
      description: product.description || "",
      price: product.price,
      imageUrl: product.imageUrl || "",
      sizes: product.sizes || [],
    });
    setSizeInput("");
    setEditingId(product.id);
    setUploadedImages([]);
    setShowForm(true);

    // Fetch existing images for this product
    try {
      const images = await getImagesMutation.refetch();
      if (images.data && images.data.length > 0) {
        setUploadedImages(images.data.map((img: any) => img.imageUrl));
      }
    } catch (error) {
      console.error("Failed to fetch product images:", error);
    }
  };

  const addSize = () => {
    if (sizeInput.trim()) {
      setFormData({
        ...formData,
        sizes: [...formData.sizes, sizeInput.trim()],
      });
      setSizeInput("");
    }
  };

  const removeSize = (index: number) => {
    setFormData({
      ...formData,
      sizes: formData.sizes.filter((_, i) => i !== index),
    });
  };

  const resetForm = () => {
    setFormData({
      name: "",
      brand: "",
      category: "",
      description: "",
      price: "",
      imageUrl: "",
      sizes: [],
    });
    setUploadedImages([]);
    setSizeInput("");
    setEditingId(null);
    setShowForm(false);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="text-2xl font-bold text-primary">UD</div>
            <span className="text-sm font-semibold tracking-wider text-primary">ADMIN PANEL</span>
          </div>
          <Button
            onClick={() => {
              if (showForm) {
                resetForm();
              } else {
                setShowForm(true);
              }
            }}
            className="bg-accent text-accent-foreground hover:bg-accent/90"
          >
            <Plus className="w-4 h-4 mr-2" />
            {showForm ? "Cancel" : "Add Product"}
          </Button>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-12">
        {/* Add/Edit Product Form */}
        {showForm && (
          <div className="bg-card border border-border rounded-lg p-8 mb-12">
            <h2 className="text-3xl font-bold mb-6 neon-text">
              {editingId ? "Edit Product" : "Add New Product"}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Product Details */}
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold mb-2">Product Name *</label>
                  <Input
                    type="text"
                    placeholder="e.g., Air Jordan 1 Retro High"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="bg-background border-border"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Brand *</label>
                  <Input
                    type="text"
                    placeholder="e.g., Jordan"
                    value={formData.brand}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                    className="bg-background border-border"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Category *</label>
                  <Input
                    type="text"
                    placeholder="e.g., Sneakers"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="bg-background border-border"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Price *</label>
                  <Input
                    type="text"
                    placeholder="e.g., ₾250-350"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    className="bg-background border-border"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">Description</label>
                <textarea
                  placeholder="Product description..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-background border border-border rounded-md p-3 text-foreground placeholder-gray-500 focus:outline-none focus:border-accent"
                  rows={4}
                />
              </div>

              {/* Image Upload */}
              <div>
                <label className="block text-sm font-semibold mb-2">Product Photos (Multiple)</label>
                <div
                  className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
                    dragActive ? "border-accent bg-accent/10" : "border-border hover:border-accent"
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-gray-400 mb-2">Drag photos here or click to select</p>
                  <p className="text-xs text-gray-500 mb-4">Max 5MB per image, multiple files allowed</p>
                  <input
                    ref={setFileInputRef}
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageUpload}
                    disabled={uploading}
                    className="sr-only"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    className="border-accent text-accent hover:bg-accent/10"
                    disabled={uploading}
                    onClick={() => fileInputRef?.click()}
                  >
                    {uploading ? "Uploading..." : "Choose Photos"}
                  </Button>
                </div>

                {/* Uploaded Images Preview */}
                {uploadedImages.length > 0 && (
                  <div className="mt-4">
                    <p className="text-sm font-semibold mb-3">Uploaded Photos ({uploadedImages.length})</p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {uploadedImages.map((url, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={url}
                            alt={`Product ${index + 1}`}
                            className="w-full h-24 object-cover rounded-lg border border-border"
                          />
                          <button
                            type="button"
                            onClick={() => removeUploadedImage(index)}
                            className="absolute top-1 right-1 p-1 bg-red-500 hover:bg-red-600 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                            title="Remove this image"
                          >
                            <X className="w-3 h-3 text-white" />
                          </button>
                          <p className="text-xs text-gray-400 mt-1 text-center">#{index + 1}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Sizes */}
              <div>
                <label className="block text-sm font-semibold mb-2">Available Sizes *</label>
                <div className="flex gap-2 mb-3">
                  <Input
                    type="text"
                    placeholder="e.g., 40"
                    value={sizeInput}
                    onChange={(e) => setSizeInput(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addSize())}
                    className="bg-background border-border"
                  />
                  <Button
                    type="button"
                    onClick={addSize}
                    variant="outline"
                    className="border-accent text-accent hover:bg-accent/10"
                  >
                    Add Size
                  </Button>
                </div>
                {formData.sizes.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {formData.sizes.map((size, index) => (
                      <div
                        key={index}
                        className="bg-accent text-accent-foreground px-3 py-1 rounded-full text-sm flex items-center gap-2"
                      >
                        {size}
                        <button
                          type="button"
                          onClick={() => removeSize(index)}
                          className="hover:text-red-300"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Submit Buttons */}
              <div className="flex gap-3 pt-6">
                <Button
                  type="submit"
                  className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90 font-bold text-lg py-6"
                >
                  {editingId ? "Update Product" : "Create Product"}
                </Button>
                <Button
                  type="button"
                  onClick={resetForm}
                  variant="outline"
                  className="border-border text-foreground hover:bg-background"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </div>
        )}

        {/* Products Table */}
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="p-6 border-b border-border">
            <h2 className="text-2xl font-bold">Products ({products?.length || 0})</h2>
          </div>

          {isLoading ? (
            <div className="p-6 text-center text-gray-400">Loading products...</div>
          ) : products && products.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-background border-b border-border">
                  <tr>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Name</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Brand</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Category</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Price</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Sizes</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((product: any) => (
                    <tr key={product.id} className="border-b border-border hover:bg-background/50 transition-colors">
                      <td className="px-6 py-4 text-sm">{product.name}</td>
                      <td className="px-6 py-4 text-sm text-accent">{product.brand}</td>
                      <td className="px-6 py-4 text-sm">{product.category}</td>
                      <td className="px-6 py-4 text-sm font-semibold neon-text">{product.price}</td>
                      <td className="px-6 py-4 text-sm">
                        <div className="flex flex-wrap gap-1">
                          {product.sizes.map((size: string) => (
                            <span key={size} className="bg-background px-2 py-1 rounded text-xs">
                              {size}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm">
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleEdit(product)}
                            className="p-2 hover:bg-background rounded transition-colors text-accent"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(product.id)}
                            className="p-2 hover:bg-background rounded transition-colors text-red-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-6 text-center text-gray-400">
              No products yet. Click "Add Product" to create one.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
