import { Button } from "@/components/ui/button";
import { MessageCircle, Filter, Search } from "lucide-react";
import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import ImageGallery from "@/components/ImageGallery";

/**
 * Urban Deal - Products Page
 * Design: Urban Streetwear Energy
 * - Product catalog with filtering
 * - Displays products from database
 * - Direct messaging integration for inquiries
 */

interface Product {
  id: number;
  name: string;
  brand: string;
  category: string;
  price: string;
  imageUrl: string | null;
  sizes: string[];
  description: string | null;
}

interface ProductWithImages extends Product {
  images: string[];
}

export default function Products() {
  const [selectedBrand, setSelectedBrand] = useState("All Brands");
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [searchQuery, setSearchQuery] = useState("");
  const [productsWithImages, setProductsWithImages] = useState<ProductWithImages[]>([]);

  // Fetch products from database
  const { data: products, isLoading } = trpc.products.list.useQuery();

  // Fetch images for each product
  useEffect(() => {
    const fetchAllImages = async () => {
      if (!products || products.length === 0) {
        setProductsWithImages([]);
        return;
      }

      const productsData = await Promise.all(
        products.map(async (product: Product) => {
          try {
            // Fetch images for this specific product using tRPC
            const response = await fetch(
              `/api/trpc/products.getImages?input=${encodeURIComponent(JSON.stringify({ productId: product.id }))}`
            );
            const result = await response.json();
            const productImages = result.result?.data || [];
            const imageUrls = productImages
              .map((img: any) => img.imageUrl)
              .filter((url: string) => url);
            
            return {
              ...product,
              images: imageUrls.length > 0 ? imageUrls : (product.imageUrl ? [product.imageUrl] : []),
            };
          } catch (error) {
            console.error(`Failed to fetch images for product ${product.id}:`, error);
            return {
              ...product,
              images: product.imageUrl ? [product.imageUrl] : [],
            };
          }
        })
      );
      setProductsWithImages(productsData);
    };

    fetchAllImages();
  }, [products]);

  // Extract unique brands and categories
  const brands = products
    ? ["All Brands", ...Array.from(new Set(products.map((p: Product) => p.brand)))]
    : ["All Brands"];
  const categories = products
    ? ["All Categories", ...Array.from(new Set(products.map((p: Product) => p.category)))]
    : ["All Categories"];

  const filteredProducts = (productsWithImages || []).filter((product: ProductWithImages) => {
    const matchesBrand = selectedBrand === "All Brands" || product.brand === selectedBrand;
    const matchesCategory =
      selectedCategory === "All Categories" || product.category === selectedCategory;
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.brand.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesBrand && matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <a href="/" className="flex items-center gap-2">
            <div className="text-2xl font-bold text-primary">UD</div>
            <span className="text-sm font-semibold tracking-wider text-primary">URBAN DEAL</span>
          </a>
          <div className="hidden md:flex items-center gap-8">
            <a href="/products" className="hover:text-accent transition-colors font-semibold text-accent">
              Products
            </a>
            <a href="/#featured" className="hover:text-accent transition-colors">
              Featured
            </a>
            <a href="/#about" className="hover:text-accent transition-colors">
              About
            </a>
            <a href="/#contact" className="hover:text-accent transition-colors">
              Contact
            </a>
          </div>
          <a href="https://wa.me/995592013611" target="_blank" rel="noopener noreferrer">
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90 font-bold">
              Inquire
            </Button>
          </a>
        </div>
      </nav>

      {/* Filters Section */}
      <section className="py-12 bg-card border-b border-border">
        <div className="container mx-auto px-4">
          <div className="space-y-6">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-background border border-border rounded-lg text-foreground placeholder-gray-500 focus:outline-none focus:border-accent"
              />
            </div>

            {/* Filters */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* Brand Filter */}
              <div>
                <label className="flex items-center gap-2 text-sm font-semibold mb-3">
                  <Filter className="w-4 h-4" />
                  Brand
                </label>
                <div className="flex flex-wrap gap-2">
                  {brands.map((brand) => (
                    <button
                      key={brand}
                      onClick={() => setSelectedBrand(brand)}
                      className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${
                        selectedBrand === brand
                          ? "bg-accent text-accent-foreground"
                          : "bg-background border border-border hover:border-accent"
                      }`}
                    >
                      {brand}
                    </button>
                  ))}
                </div>
              </div>

              {/* Category Filter */}
              <div>
                <label className="flex items-center gap-2 text-sm font-semibold mb-3">
                  <Filter className="w-4 h-4" />
                  Category
                </label>
                <div className="flex flex-wrap gap-2">
                  {categories.map((category) => (
                    <button
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${
                        selectedCategory === category
                          ? "bg-accent text-accent-foreground"
                          : "bg-background border border-border hover:border-accent"
                      }`}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          {isLoading ? (
            <div className="text-center py-16">
              <p className="text-gray-400 text-lg">Loading products...</p>
            </div>
          ) : filteredProducts.length > 0 ? (
            <>
              <p className="text-gray-400 mb-8">
                Showing {filteredProducts.length} product{filteredProducts.length !== 1 ? "s" : ""}
              </p>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredProducts.map((product: ProductWithImages) => (
                  <div
                    key={product.id}
                    className="bg-card border border-border rounded-lg overflow-hidden hover:border-accent transition-all hover:shadow-lg hover:shadow-accent/50 group"
                  >
                    {/* Product Image Gallery */}
                    <div className="relative p-4 bg-background">
                      <ImageGallery images={product.images} productName={product.name} />
                      <div className="absolute top-8 right-8 bg-accent text-accent-foreground px-3 py-1 rounded-full text-sm font-bold">
                        {product.category}
                      </div>
                    </div>

                    {/* Product Info */}
                    <div className="p-6">
                      <p className="text-accent text-sm font-semibold mb-2">{product.brand}</p>
                      <h3 className="text-xl font-bold mb-2">{product.name}</h3>
                      <p className="text-gray-400 text-sm mb-4">{product.description}</p>

                      {/* Price */}
                      <div className="mb-4">
                        <p className="text-2xl font-bold neon-text">{product.price}</p>
                      </div>

                      {/* Sizes */}
                      <div className="mb-6">
                        <p className="text-sm font-semibold mb-2">Available Sizes:</p>
                        <div className="flex flex-wrap gap-2">
                          {product.sizes.map((size) => (
                            <span
                              key={size}
                              className="px-3 py-1 bg-background border border-border rounded text-sm"
                            >
                              {size}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex gap-3">
                        <a
                          href={`https://wa.me/995592013611?text=Hi! I'm interested in the ${product.name} (${product.brand}). Can you provide more details?`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex-1"
                        >
                          <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90 font-bold">
                            <MessageCircle className="w-4 h-4 mr-2" />
                            Inquire
                          </Button>
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-16">
              <p className="text-gray-400 text-lg mb-4">No products found matching your filters.</p>
              <button
                onClick={() => {
                  setSelectedBrand("All Brands");
                  setSelectedCategory("All Categories");
                  setSearchQuery("");
                }}
                className="text-accent hover:underline font-semibold"
              >
                Clear Filters
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-lg font-bold mb-4 text-primary">Urban Deal</h3>
              <p className="text-gray-400 text-sm">
                Premium sneakers and streetwear for the urban culture enthusiast.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <a href="/products" className="hover:text-accent transition-colors">
                    Products
                  </a>
                </li>
                <li>
                  <a href="/#featured" className="hover:text-accent transition-colors">
                    Featured
                  </a>
                </li>
                <li>
                  <a href="/#about" className="hover:text-accent transition-colors">
                    About
                  </a>
                </li>
                <li>
                  <a href="/#contact" className="hover:text-accent transition-colors">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Follow Us</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <a
                    href="https://instagram.com/urbandeal_"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-accent transition-colors"
                  >
                    Instagram
                  </a>
                </li>
                <li>
                  <a
                    href="https://tiktok.com/@urabandeal"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-accent transition-colors"
                  >
                    TikTok
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Info</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Tbilisi, Georgia</li>
                <li>Always Open</li>
                <li>100% Original</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border pt-8 text-center text-gray-400 text-sm">
            <p>
              © 2026 Urban Deal. All rights reserved. | Built for sneaker enthusiasts
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
