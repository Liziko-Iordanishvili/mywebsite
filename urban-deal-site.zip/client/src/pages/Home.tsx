import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Mail, MapPin, Phone, Globe, Zap } from "lucide-react";

/**
 * Urban Deal - Premium Sneakers & Streetwear
 * Design: Urban Streetwear Energy with Brand Identity
 * - Dark charcoal background with neutral gray branding
 * - Vibrant accent colors (hot pink, cyan, lime) for energy
 * - Bold Bebas Neue typography for headlines
 * - Diagonal cuts and layered imagery
 * - High-energy, youth-focused aesthetic
 */

export default function Home() {
  // The userAuth hooks provides authentication state
  // To implement login/logout functionality, simply call logout() or redirect to getLoginUrl()
  let { user, loading, error, isAuthenticated, logout } = useAuth();

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="text-2xl font-bold text-primary">UD</div>
            <span className="text-sm font-semibold tracking-wider text-primary">URBAN DEAL</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="/products" className="hover:text-accent transition-colors">
              Products
            </a>
            <a href="#featured" className="hover:text-accent transition-colors">
              Featured
            </a>
            <a href="#about" className="hover:text-accent transition-colors">
              About
            </a>
            <a href="#contact" className="hover:text-accent transition-colors">
              Contact
            </a>
          </div>
          <a href="/products">
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90 font-bold">
              Shop Now
            </Button>
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative w-full h-screen flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://d2xsxph8kpxj0f.cloudfront.net/310519663656129605/HjXN7MUivvWnrhMLhZhcqy/hero-sneaker-showcase-NHa2tmJfmBASymRjHsch5D.webp')`,
            backgroundAttachment: "fixed",
          }}
        >
          <div className="absolute inset-0 bg-black/40"></div>
        </div>

        <div className="relative z-10 container mx-auto px-4 text-center">
          <div className="animate-fade-in">
            <h1 className="text-6xl md:text-8xl font-bold mb-4 neon-text drop-shadow-lg animate-pulse">
              STEP AHEAD
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200 font-light">
              Premium Sneakers. Limitless Style.
            </p>
            <div className="flex flex-col md:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-accent text-accent-foreground hover:bg-accent/90 text-lg px-8 py-6 font-bold transform hover:scale-105 transition-transform"
              >
                Explore Collection
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-accent text-accent hover:bg-accent/10 text-lg px-8 py-6 font-bold"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce">
          <div className="w-6 h-10 border-2 border-accent rounded-full flex items-start justify-center p-2">
            <div className="w-1 h-2 bg-accent rounded-full animate-pulse"></div>
          </div>
        </div>
      </section>

      {/* Featured Section */}
      <section id="featured" className="py-20 bg-background relative">
        <div className="container mx-auto px-4">
          <div className="mb-16">
            <h2 className="text-5xl md:text-6xl font-bold mb-4">
              <span className="text-primary">URBAN</span> <span className="neon-text">DEAL</span>
            </h2>
            <p className="text-lg text-gray-400 max-w-2xl font-semibold">
              Streetwear Collection
            </p>
          </div>

          {/* Featured Grid */}
          <div className="grid md:grid-cols-2 gap-8 mb-16">
            {/* Featured Image 1 */}
            <div className="relative group overflow-hidden rounded-lg diagonal-cut">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663656129605/HjXN7MUivvWnrhMLhZhcqy/featured-collection-banner-2uFEK52WXa23rZmNMkjq26.webp"
                alt="Featured Collection"
                className="w-full h-96 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-6">
                <div>
                  <h3 className="text-2xl font-bold neon-text mb-2 animate-pulse">
                    New Arrivals
                  </h3>
                  <p className="text-gray-200">Latest drops exclusive to our store</p>
                </div>
              </div>
            </div>

            {/* Featured Image 2 */}
            <div className="relative group overflow-hidden rounded-lg diagonal-cut-reverse">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663656129605/HjXN7MUivvWnrhMLhZhcqy/brand-lifestyle-image-ewiB3D7wAE9k3yahnaHsqn.webp"
                alt="Lifestyle"
                className="w-full h-96 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-6">
                <div>
                  <h3 className="text-2xl font-bold neon-text-pink mb-2 animate-pulse">
                    Urban Culture
                  </h3>
                  <p className="text-gray-200">Express your style, own your vibe</p>
                </div>
              </div>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-3 gap-6 mt-16 pt-16 border-t border-border">
            <div className="p-6 bg-card rounded-lg hover:border-accent transition-colors border border-border hover:shadow-lg hover:shadow-accent/50">
              <div className="flex items-center gap-3 mb-4">
                <Zap className="w-6 h-6 text-accent" />
                <h3 className="text-lg font-bold">100% Original</h3>
              </div>
              <p className="text-gray-400">
                All products are authentic and verified. We guarantee premium quality.
              </p>
            </div>

            <div className="p-6 bg-card rounded-lg hover:border-accent transition-colors border border-border hover:shadow-lg hover:shadow-accent/50">
              <div className="flex items-center gap-3 mb-4">
                <Globe className="w-6 h-6 text-accent" />
                <h3 className="text-lg font-bold">Worldwide Shipping</h3>
              </div>
              <p className="text-gray-400">
                We deliver to customers worldwide with reliable international shipping.
              </p>
            </div>

            <div className="p-6 bg-card rounded-lg hover:border-accent transition-colors border border-border hover:shadow-lg hover:shadow-accent/50">
              <div className="flex items-center gap-3 mb-4">
                <MapPin className="w-6 h-6 text-accent" />
                <h3 className="text-lg font-bold">Local Delivery</h3>
              </div>
              <p className="text-gray-400">
                Fast local delivery available in Tbilisi, Georgia. Same-day options available.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-card relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>

        <div className="container mx-auto px-4 relative z-10">
          <h2 className="text-5xl md:text-6xl font-bold mb-12">
            About <span className="text-primary">Urban</span> <span className="neon-text">Deal</span>
          </h2>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-lg text-gray-300 mb-6 leading-relaxed">
                Urban Deal is your destination for premium sneakers and streetwear. We specialize in bringing the latest drops and exclusive collections from top brands to Tbilisi and beyond.
              </p>
              <p className="text-lg text-gray-300 mb-6 leading-relaxed">
                With a commitment to authenticity and quality, we ensure every product meets our high standards. Whether you're a sneaker enthusiast or fashion-forward individual, Urban Deal has something for you.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-accent rounded-full"></div>
                  <span>Verified Authentic Products</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-accent rounded-full"></div>
                  <span>Premium Brand Selection</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-accent rounded-full"></div>
                  <span>Expert Customer Service</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="neon-border p-8 rounded-lg hover:shadow-lg hover:shadow-accent/50 transition-all">
                <div className="bg-background p-6 rounded-lg">
                  <h3 className="text-2xl font-bold mb-6 neon-text">Why Choose Us?</h3>
                  <ul className="space-y-4 text-gray-300">
                    <li className="flex gap-3">
                      <span className="text-accent font-bold">✓</span>
                      <span>Curated collection of premium sneakers and streetwear</span>
                    </li>
                    <li className="flex gap-3">
                      <span className="text-accent font-bold">✓</span>
                      <span>Fast and reliable shipping worldwide</span>
                    </li>
                    <li className="flex gap-3">
                      <span className="text-accent font-bold">✓</span>
                      <span>Local delivery options in Tbilisi</span>
                    </li>
                    <li className="flex gap-3">
                      <span className="text-accent font-bold">✓</span>
                      <span>100% authentic products guaranteed</span>
                    </li>
                    <li className="flex gap-3">
                      <span className="text-accent font-bold">✓</span>
                      <span>Responsive customer support</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-5xl md:text-6xl font-bold mb-12 text-center">
            Get in <span className="text-primary">Touch</span>
          </h2>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {/* Phone */}
            <div className="bg-card p-8 rounded-lg border border-border hover:border-accent transition-colors text-center hover:shadow-lg hover:shadow-accent/50">
              <Phone className="w-12 h-12 text-accent mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Phone</h3>
              <a
                href="tel:+995592013611"
                className="text-accent hover:underline text-lg font-semibold"
              >
                +995 592 01 36 11
              </a>
            </div>

            {/* Email */}
            <div className="bg-card p-8 rounded-lg border border-border hover:border-accent transition-colors text-center hover:shadow-lg hover:shadow-accent/50">
              <Mail className="w-12 h-12 text-accent mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Email</h3>
              <a
                href="mailto:shop.udeal@gmail.com"
                className="text-accent hover:underline text-lg font-semibold"
              >
                shop.udeal@gmail.com
              </a>
            </div>

            {/* Location */}
            <div className="bg-card p-8 rounded-lg border border-border hover:border-accent transition-colors text-center hover:shadow-lg hover:shadow-accent/50">
              <MapPin className="w-12 h-12 text-accent mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Location</h3>
              <p className="text-gray-300">Tbilisi, Georgia</p>
            </div>
          </div>

          {/* CTA */}
          <div className="mt-16 text-center">
            <p className="text-lg text-gray-400 mb-6">
              DM us on Instagram or contact us directly for inquiries
            </p>
            <div className="flex flex-col md:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-accent text-accent-foreground hover:bg-accent/90 text-lg px-8 py-6 font-bold transform hover:scale-105 transition-transform"
              >
                Message on Instagram
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-accent text-accent hover:bg-accent/10 text-lg px-8 py-6 font-bold"
              >
                Follow on TikTok
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-lg font-bold mb-4 text-primary">Urban Deal</h3>
              <p className="text-gray-400 text-sm">
                Premium sneakers and streetwear for the urban culture enthusiast.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <a href="/products" className="hover:text-accent transition-colors">
                    Products
                  </a>
                </li>
                <li>
                  <a href="#featured" className="hover:text-accent transition-colors">
                    Featured
                  </a>
                </li>
                <li>
                  <a href="#about" className="hover:text-accent transition-colors">
                    About
                  </a>
                </li>
                <li>
                  <a href="#contact" className="hover:text-accent transition-colors">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Follow Us</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <a
                    href="https://instagram.com/urbandeal_"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-accent transition-colors"
                  >
                    Instagram
                  </a>
                </li>
                <li>
                  <a
                    href="https://tiktok.com/@urabandeal"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-accent transition-colors"
                  >
                    TikTok
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Info</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Tbilisi, Georgia</li>
                <li>Always Open</li>
                <li>100% Original</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border pt-8 text-center text-gray-400 text-sm">
            <p>
              &copy; 2026 Urban Deal. All rights reserved. | Built for sneaker enthusiasts
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
