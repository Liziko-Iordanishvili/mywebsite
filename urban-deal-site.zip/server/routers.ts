import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getAllProducts, createProduct, updateProduct, deleteProduct, getProductImages, addProductImage, deleteProductImage } from "./db";
import { TRPCError } from "@trpc/server";
import { storagePut } from "./storage";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  products: router({
    list: publicProcedure.query(async () => {
      const allProducts = await getAllProducts();
      const productsWithImages = await Promise.all(
        allProducts.map(async (p) => {
          const images = await getProductImages(p.id);
          const imageUrls = images.map((img: any) => img.imageUrl).filter((url: string) => url);
          return {
            ...p,
            sizes: JSON.parse(p.sizes || "[]"),
            images: imageUrls.length > 0 ? imageUrls : (p.imageUrl ? [p.imageUrl] : []),
          };
        })
      );
      return productsWithImages;
    }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        brand: z.string().min(1),
        category: z.string().min(1),
        description: z.string().optional(),
        price: z.string().min(1),
        imageUrl: z.string().optional(),
        sizes: z.array(z.string()).min(1),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin only" });
        }
        const product = await createProduct({
          name: input.name,
          brand: input.brand,
          category: input.category,
          description: input.description,
          price: input.price,
          imageUrl: input.imageUrl,
          sizes: JSON.stringify(input.sizes),
        });
        return product ? { ...product, sizes: JSON.parse(product.sizes || "[]") } : null;
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        brand: z.string().optional(),
        category: z.string().optional(),
        description: z.string().optional(),
        price: z.string().optional(),
        imageUrl: z.string().optional(),
        sizes: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin only" });
        }
        const updates: any = {};
        if (input.name) updates.name = input.name;
        if (input.brand) updates.brand = input.brand;
        if (input.category) updates.category = input.category;
        if (input.description !== undefined) updates.description = input.description;
        if (input.price) updates.price = input.price;
        if (input.imageUrl !== undefined) updates.imageUrl = input.imageUrl;
        if (input.sizes) updates.sizes = JSON.stringify(input.sizes);
        await updateProduct(input.id, updates);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin only" });
        }
        await deleteProduct(input.id);
        return { success: true };
      }),

    uploadImage: protectedProcedure
      .input(z.object({
        file: z.instanceof(Uint8Array),
        filename: z.string(),
        mimeType: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin only" });
        }
        try {
          const { url } = await storagePut(
            `products/${Date.now()}-${input.filename}`,
            input.file,
            input.mimeType
          );
          return { url, success: true };
        } catch (error) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to upload image",
          });
        }
      }),

    getImages: publicProcedure
      .input(z.object({ productId: z.number() }))
      .query(async ({ input }) => {
        return await getProductImages(input.productId);
      }),

    addImage: protectedProcedure
      .input(z.object({
        productId: z.number(),
        imageUrl: z.string(),
        displayOrder: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin only" });
        }
        try {
          const image = await addProductImage({
            productId: input.productId,
            imageUrl: input.imageUrl,
            displayOrder: input.displayOrder || 0,
          });
          return { success: true, image };
        } catch (error) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to add image",
          });
        }
      }),

    deleteImage: protectedProcedure
      .input(z.object({ imageId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin only" });
        }
        try {
          await deleteProductImage(input.imageId);
          return { success: true };
        } catch (error) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to delete image",
          });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
