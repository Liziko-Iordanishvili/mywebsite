import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock admin user context
function createAdminContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "admin-user",
      email: "admin@example.com",
      name: "Admin User",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TRPCContext["res"],
  };
}

// Mock regular user context
function createUserContext(): TrpcContext {
  return {
    user: {
      id: 2,
      openId: "regular-user",
      email: "user@example.com",
      name: "Regular User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TRPCContext["res"],
  };
}

describe("Product Management", () => {
  describe("products.list", () => {
    it("should return a list of products (public access)", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const products = await caller.products.list();
      expect(Array.isArray(products)).toBe(true);
    });
  });

  describe("products.create", () => {
    it("should allow admin to create a product", async () => {
      const adminCtx = createAdminContext();
      const caller = appRouter.createCaller(adminCtx);

      const newProduct = {
        name: "Test Sneaker " + Date.now(),
        brand: "TestBrand",
        category: "Sneakers",
        description: "A test sneaker",
        price: "₾100-150",
        imageUrl: "https://example.com/image.jpg",
        sizes: ["40", "41", "42"],
      };

      const result = await caller.products.create(newProduct);
      expect(result).toBeDefined();
      expect(result?.name).toBe(newProduct.name);
      expect(result?.brand).toBe("TestBrand");
      expect(result?.sizes).toEqual(["40", "41", "42"]);
    });

    it("should deny regular user from creating a product", async () => {
      const userCtx = createUserContext();
      const caller = appRouter.createCaller(userCtx);

      const newProduct = {
        name: "Test Sneaker " + Date.now(),
        brand: "TestBrand",
        category: "Sneakers",
        description: "A test sneaker",
        price: "₾100-150",
        imageUrl: "https://example.com/image.jpg",
        sizes: ["40", "41", "42"],
      };

      try {
        await caller.products.create(newProduct);
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });

    it("should validate required fields", async () => {
      const adminCtx = createAdminContext();
      const caller = appRouter.createCaller(adminCtx);

      const invalidProduct = {
        name: "",
        brand: "TestBrand " + Date.now(),
        category: "Sneakers",
        price: "₾100-150",
        sizes: ["40"],
      };

      try {
        await caller.products.create(invalidProduct as any);
        expect.fail("Should have thrown a validation error");
      } catch (error: any) {
        expect(error.message).toBeDefined();
      }
    });
  });

  describe("products.update", () => {
    it("should allow admin to update a product", async () => {
      const adminCtx = createAdminContext();
      const caller = appRouter.createCaller(adminCtx);

      // First create a product
      const newProduct = {
        name: "Original Name " + Date.now(),
        brand: "OriginalBrand",
        category: "Sneakers",
        price: "₾100",
        sizes: ["40"],
      };

      const created = await caller.products.create(newProduct);
      if (!created) throw new Error("Failed to create product");

      // Then update it
      const updateResult = await caller.products.update({
        id: created.id,
        name: "Updated Name " + Date.now(),
        price: "₾150",
      });

      expect(updateResult.success).toBe(true);
    });

    it("should deny regular user from updating a product", async () => {
      const userCtx = createUserContext();
      const caller = appRouter.createCaller(userCtx);

      try {
        await caller.products.update({
          id: 1,
          name: "Updated Name " + Date.now(),
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });
  });

  describe("products.delete", () => {
    it("should allow admin to delete a product", async () => {
      const adminCtx = createAdminContext();
      const caller = appRouter.createCaller(adminCtx);

      // First create a product
      const newProduct = {
        name: "To Delete " + Date.now(),
        brand: "DeleteBrand",
        category: "Sneakers",
        price: "₾100",
        sizes: ["40"],
      };

      const created = await caller.products.create(newProduct);
      if (!created) throw new Error("Failed to create product");

      // Then delete it
      const deleteResult = await caller.products.delete({
        id: created.id,
      });

      expect(deleteResult.success).toBe(true);
    });

    it("should deny regular user from deleting a product", async () => {
      const userCtx = createUserContext();
      const caller = appRouter.createCaller(userCtx);

      try {
        await caller.products.delete({
          id: 1,
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });
  });
});
